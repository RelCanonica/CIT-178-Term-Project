CREATE DATABASE kpopDB
GO

USE kpopDB;
CREATE TABLE Groups(
	GroupID int NOT NULL,
	GroupName varchar(30) NOT NULL,
	DebutDate date,
	DebutSingle varchar(100),
	LabelID varchar(5),
	PRIMARY KEY(GroupID)
	);
GO

CREATE TABLE Show(
	ShowID varchar(5) NOT NULL,
	ShowName varChar(30),
	PRIMARY KEY(ShowID)
	);
GO

CREATE TABLE Wins(
	GroupID int NOT NULL,
	ShowID varchar(5) NOT NULL,
	WinDate date NOT NULL,
	PRIMARY KEY(WinDate),
	);
GO

CREATE TABLE Album(
	AlbumID varchar(50) NOT NULL,
	GroupID int NOT NULL,
	AlbumName varchar(100),
	AlbumDate date NOT NULL,
	GenreID varchar(15),
	AlbumCost money,
	PRIMARY KEY(AlbumID),
	);
GO

CREATE TABLE Genre(
	GenreID varchar(15) NOT NULL,
	GenreName varChar(30),
	PRIMARY KEY(GenreID)
	);
GO

CREATE TABLE Label(
	LabelID varchar(5) NOT NULL,
	LabelName varchar(30),
	LabelOwner varchar(30),
	PRIMARY KEY(LabelID)
	);
GO
/*
CREATE TABLE GroupMembers(
	GroupID int NOT NULL,
	MemberID int NOT NULL,
	MemberName varchar(30),
	LabelID varchar(5),
	PRIMARY KEY(MemberID)
	);
GO*/

USE kpopDB;
GO

ALTER TABLE Groups WITH CHECK
ADD CONSTRAINT FK_LabelID FOREIGN KEY(LabelID) REFERENCES Label(LabelID)
ON UPDATE CASCADE
GO

ALTER TABLE Wins WITH CHECK
ADD CONSTRAINT FK_GroupID FOREIGN KEY(GroupID) REFERENCES Groups(GroupID)
ON UPDATE CASCADE
GO

ALTER TABLE Wins WITH CHECK
ADD CONSTRAINT FK_ShowID FOREIGN KEY(ShowID) REFERENCES Show(ShowID)
ON UPDATE CASCADE
GO

ALTER TABLE Album WITH CHECK
ADD CONSTRAINT FK_GroupID2 FOREIGN KEY(GroupID) REFERENCES Groups(GroupID)
ON UPDATE CASCADE
GO

ALTER TABLE Album WITH CHECK
ADD CONSTRAINT FK_GenreID FOREIGN KEY(GenreID) REFERENCES Genre(GenreID)
ON UPDATE CASCADE
GO

USE kpopDB;
GO

CREATE INDEX idx_GenreID ON Album(GenreID);
GO
CREATE INDEX idx_LabelID ON Groups(LabelID);
GO
CREATE INDEX idx_GroupID ON Album(GroupID);
GO
CREATE INDEX idx_GroupID2 ON Wins(GroupID);
GO
CREATE INDEX idx_ShowID ON Wins(ShowID);

INSERT INTO Label VALUES('JYP', 'JYP Entertainment', 'Park Jinyoung')
INSERT INTO Label VALUES('KQ', 'KQ Entertainment', 'Kim Gyu Uk')
INSERT INTO Label VALUES('HYBE', 'HYBE Labels', 'Park Jiwon')
INSERT INTO Label VALUES('RBW', 'RBW', 'Kim Jinwoo')
INSERT INTO Label VALUES('SM', 'SM Entertainment', 'Lee Sooman')
INSERT INTO Label VALUES('WM', 'Widmay Entertainment', NULL)
INSERT INTO Label VALUES('YG', 'YG Entertainment', 'Yang Hyunsuk')

INSERT INTO Show VALUES('TS', 'The Show')
INSERT INTO Show VALUES('MC', 'Music Core')
INSERT INTO Show VALUES('IK', 'Inkigayo')
INSERT INTO Show VALUES('Mco', 'M Countdown')
INSERT INTO Show VALUES('SC', 'Show Champion')

INSERT INTO Genre VALUES('Rock', 'Rock')
INSERT INTO Genre VALUES('Pop', 'Pop')
INSERT INTO Genre VALUES('R&B', 'R&B')
INSERT INTO Genre VALUES('EDM', 'Electronic')
INSERT INTO Genre VALUES('HipHop', 'HipHop')

INSERT INTO Groups VALUES(1,'Day6','9/7/2015','Congratulations','JYP')
INSERT INTO Groups VALUES(2,'ATEEZ','10/28/2018','Pirate King','KQ')
INSERT INTO Groups VALUES(3,'BTS','7/8/2013','No More Dream','HYBE')
INSERT INTO Groups VALUES(4,'ONEWE','5/6/2019','Ring on My Ears','RBW')
INSERT INTO Groups VALUES(5,'SHINee','3/2/2008','Replay','SM')
INSERT INTO Groups VALUES(6,'EXO','4/9/2010','MAMA','SM')
INSERT INTO Groups VALUES(7,'Snuper','8/4/2015','Shall We Dance','WM')

INSERT INTO Album VALUES('Day6-1',1,'Sunrise','5/6/2016','Rock',$14.99)
INSERT INTO Album VALUES('Day6-2',1,'The Book of Us: Negetropy','8/4/2018','Rock', $16.99)
INSERT INTO Album VALUES('ATEEZ-1',2,'All to Action','1/21/2020','Pop', $20.99)
INSERT INTO Album VALUES('BTS-1',3,'O!RUL8,2?','9/8/2014','Pop', $32.00)
INSERT INTO Album VALUES('BTS-2',3,'Young Forever','5/13/2016','Pop', $16.99)
INSERT INTO Album VALUES('BTS-3',3,'Wings','9/18/2018','Pop', $12.99)
INSERT INTO Album VALUES('ONEWE-1',4,'ONE','1/8/2021','Rock', $19.99)
INSERT INTO Album VALUES('SHINee-1',5,'The Shinee World','10/9/2008','R&B', $15.99)
INSERT INTO Album VALUES('EXO-1',6,'XOXO','7/9/2012','Pop', $20.00)
INSERT INTO Album VALUES('EXO-2',6,'The War','9/22/2020','Pop', $15.99)
INSERT INTO Album VALUES('Snuper-1',7,'Shall We','1/4/2018','Pop', $18.99)

INSERT INTO Wins VALUES(1,'TS','5/6/2017')
INSERT INTO Wins VALUES(2,'TS','8/4/2019')
INSERT INTO Wins VALUES(3,'MC','1/21/2021')
INSERT INTO Wins VALUES(4,'TS','9/8/2015')
INSERT INTO Wins VALUES(5,'MC','5/13/2017')
INSERT INTO Wins VALUES(6,'IK','9/18/2019')
INSERT INTO Wins VALUES(7,'TS','9/18/2029')

SELECT * FROM Wins;