CREATE DATABASE kpopDB

GO

USE kpopDB;
CREATE TABLE Groups(
	GroupID int NOT NULL,
	GroupName varchar(30) NOT NULL,
	DebutDate datetime,
	DebutSingle varchar(100),
	LabelID varchar(5),
	PRIMARY KEY(GroupID)
	);

GO

CREATE TABLE Show(
	ShowID varchar(5) NOT NULL,
	ShowName varChar(30),
	PRIMARY KEY(ShowID)
	);

GO

CREATE TABLE Wins(
	GroupID int NOT NULL,
	ShowID varchar(5) NOT NULL,
	WinDate datetime NOT NULL,
	PRIMARY KEY(WinDate),
	);

GO

CREATE TABLE Album(
	AlbumID varchar(50) NOT NULL,
	GroupID int NOT NULL,
	AlbumName varchar(100),
	AlbumDate datetime NOT NULL,
	GenreID varchar(15),
	PRIMARY KEY(AlbumID),
	);

GO

CREATE TABLE Genre(
	GenreID varchar(15) NOT NULL,
	GenreName varChar(30),
	PRIMARY KEY(GenreID)
	);

GO

CREATE TABLE Label(
	LabelID varchar(5) NOT NULL,
	LabelNAME varchar(30),
	LabelOwner varchar(30),
	PRIMARY KEY(LabelID)
	);

GO