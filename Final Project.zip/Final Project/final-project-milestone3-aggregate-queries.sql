/*
USE kpopDB;
SELECT MIN(GroupName) AS FirstGroup, MAX(GroupName) AS LastGroup,
COUNT(GroupName) AS NumberOfGroups
FROM Groups;*/

/*USE kpopDB;
SELECT MIN(AlbumCost) AS CheapestAlbum, MAX(AlbumCost) AS ExpensiveAlbum,
AVG(AlbumCost) AS AverageCost
FROM Album*/

/*USE kpopDB;
SELECT SUM(AlbumCost) AS 'Total Cost of Albums',
COUNT(AlbumID) AS 'Total Albums'
FROM Album*/

/*USE kpopDB;
SELECT
COUNT(WinDate) AS TotalWins,
FROM Wins
WHERE GroupID = 1*/

