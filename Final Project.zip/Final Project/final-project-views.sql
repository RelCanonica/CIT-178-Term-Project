/* 

USE kpopDB;
GO

View #1  

-- updatable view --
CREATE VIEW Debut
AS
SELECT GroupName, DebutDate, DebutSingle
FROM Groups;
GO

-- original data --
SELECT * FROM Debut;

-- updating Debut Date --
GO
UPDATE Debut
SET DebutDate= '5/6/2008'
WHERE GroupName='Ateez';
GO

-- displaying new data --
USE kpopDB;
SELECT * FROM Debut;

View #2 

--  creating view --
CREATE VIEW LabelWins
AS
SELECT ShowID, WinDate, LabelID
FROM Wins JOIN Groups ON Wins.GroupID = Groups.GroupID;
GO

-- using the view to display the data --
USE kpopDB;
SELECT * FROM LabelWins;

View #3 

-- creating view --
GO
CREATE VIEW RecentAlbums
AS
SELECT AlbumName, AlbumDate, GroupID FROM Album
WHERE AlbumDate > '2019-01-01'
GO

-- using the view to display the data --
SELECT * FROM RecentAlbums;

View #4

-- creating view --
GO
CREATE VIEW CheapAlbums
AS
SELECT GroupName, AlbumName, AlbumCost
FROM Album JOIN Groups ON Album.GroupID = Groups.GroupID
WHERE AlbumCost < '20';
GO

-- using the view to display the data --
SELECT * FROM CheapAlbums;

*/