
/*

Create a stored procedure that retrieves and displays data  (2 points)

Create a stored procedure that takes 1 or more input parameters and retrieves results based on the value  (3 points)

Create a stored procedure that takes 1 or more input parameters and includes 1 or more output parameters (3 points)

Create a stored procedure that includes a return value (3 points)

Create a scalar function that accepts an argument.  (3 points)

Create a table function that accepts at least one argument  (3 points)

Create a trigger that will add deleted data from one of your tables into an archive or transaction table (you will need to create the table before creating the trigger)  8 points

Create an insert trigger that adds to the archive or transaction table when a row is inserted  (5 points)

Create an update trigger that adds to the archive or transaction table when a row is modified(5 points)

*/


/* Final Project Procedures */ 

-- Retrieves and displays data

/*

USE KpopDB;
GO
CREATE PROC spGroups
AS
SELECT * FROM Groups
ORDER BY GroupName;
GO

EXEC spGroups;



-- Takes an input parameter
USE kpopDB;
GO
CREATE PROC spGetGroup
	@GroupName varchar(30)
AS
BEGIN
	SELECT * FROM Groups
	WHERE GroupName = @GroupName;
END
GO
EXEC spGetGroup ATEEZ

*/

/* Final Project User Defined Functions */ 

-- creates the scalar function (finds all albums by ATEEZ)

/*

USE kpopDB;
GO
CREATE PROC spFindAlbum
	@Album nvarchar(40) = '%'
AS
BEGIN
	SELECT AlbumDate, AlbumName
	FROM Album
	WHERE AlbumID LIKE @Album;
END
GO
EXEC spFindAlbum 'ATEEZ%';
*/

-- creates the table function
/*
CREATE FUNCTION fnWinners
    (@CutOff int = 1)
    RETURNS table
    RETURN (SELECT Groups.GroupName, COUNT(WinDate) AS 'TotalWins'
                FROM WINS JOIN Groups ON Groups.GroupID = Wins.GroupID
                WHERE ISNUMERIC('TotalWins') > 1
                GROUP BY GroupName);
			




/* Final Project Triggers */ 

USE kpopDB;
GO
CREATE TRIGGER Album_INSERT_UPDATE ON Album
AFTER INSERT,UPDATE
AS
UPDATE Album SET AlbumCost = AlbumCost * .75
WHERE AlbumID IN (SELECT AlbumID FROM Inserted);

*/	


USE kpopDB;
GO
CREATE TRIGGER GroupName_Update ON Groups
AFTER INSERT,UPDATE
AS
UPDATE Groups SET GroupID = GroupName
WHERE GroupID IN (SELECT GroupID FROM Inserted);