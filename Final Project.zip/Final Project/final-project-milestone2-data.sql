USE kpopDB;

/*INSERT INTO Label VALUES('JYP', 'JYP Entertainment', 'Park Jinyoung')
INSERT INTO Label VALUES('KQ', 'KQ Entertainment', 'Kim Gyu Uk')
INSERT INTO Label VALUES('HYBE', 'HYBE Labels', 'Park Jiwon')
INSERT INTO Label VALUES('RBW', 'RBW', 'Kim Jinwoo')
INSERT INTO Label VALUES('SM', 'SM Entertainment', 'Lee Sooman')
INSERT INTO Label VALUES('WM', 'Widmay Entertainment', NULL)
INSERT INTO Label VALUES('YG', 'YG Entertainment', 'Yang Hyunsuk')

INSERT INTO Show VALUES('TS', 'The Show')
INSERT INTO Show VALUES('MC', 'Music Core')
INSERT INTO Show VALUES('IK', 'Inkigayo')
INSERT INTO Show VALUES('Mco', 'M Countdown')
INSERT INTO Show VALUES('SC', 'Show Champion')

INSERT INTO Genre VALUES('Rock', 'Rock')
INSERT INTO Genre VALUES('Pop', 'Pop')
INSERT INTO Genre VALUES('R&B', 'R&B')
INSERT INTO Genre VALUES('EDM', 'Electronic')
INSERT INTO Genre VALUES('HipHop', 'HipHop')

INSERT INTO Groups VALUES('1','Day6','9/7/2015','Congratulations','JYP')
INSERT INTO Groups VALUES('2','ATEEZ','10/28/2018','Pirate King','KQ')
INSERT INTO Groups VALUES('3','BTS','7/8/2013','No More Dream','HYBE')
INSERT INTO Groups VALUES('4','ONEWE','5/6/2019','Ring on My Ears','RBW')
INSERT INTO Groups VALUES('5','SHINee','3/2/2008','Replay','SM')
INSERT INTO Groups VALUES('6','EXO','4/9/2010','MAMA','SM')
INSERT INTO Groups VALUES('7','Snuper','8/4/2015','Shall We Dance','WM')

INSERT INTO Album VALUES('Day6-1','1','Sunrise','5/6/2016','Rock')
INSERT INTO Album VALUES('Day6-2','1','The Book of Us: Negetropy','8/4/2018','Rock')
INSERT INTO Album VALUES('ATEEZ-1','2','All to Action','1/21/2020','Pop')
INSERT INTO Album VALUES('BTS-1','3','O!RUL8,2?','9/8/2014','Pop')
INSERT INTO Album VALUES('BTS-2','3','Young Forever','5/13/2016','Pop')
INSERT INTO Album VALUES('BTS-3','3','Wings','9/18/2018','Pop')
INSERT INTO Album VALUES('ONEWE-1','4','ONE','1/8/2021','Rock')
INSERT INTO Album VALUES('SHINee-1','5','The Shinee World','10/9/2008','R&B')
INSERT INTO Album VALUES('EXO-1','6','XOXO','7/9/2012','Pop')
INSERT INTO Album VALUES('EXO-2','6','The War','9/22/2020','Pop')
INSERT INTO Album VALUES('Snuper-1','7','Shall We','1/4/2018','Pop')

INSERT INTO Wins VALUES('1','TS','5/6/2017')
INSERT INTO Wins VALUES('2','TS','8/4/2019')
INSERT INTO Wins VALUES('3','MC','1/21/2021')
INSERT INTO Wins VALUES('4','TS','9/8/2015')
INSERT INTO Wins VALUES('5','MC','5/13/2017')
INSERT INTO Wins VALUES('6','IK','9/18/2019')
INSERT INTO Wins VALUES('7','TS','9/18/2029')*/

SELECT * FROM Wins;

