/*USE kpopDB;
GO

CREATE INDEX idx_GenreID ON Album(GenreID);
GO
CREATE INDEX idx_LabelID ON Groups(LabelID);
GO
CREATE INDEX idx_GroupID ON Album(GroupID);
GO
CREATE INDEX idx_GroupID2 ON Wins(GroupID);
GO
CREATE INDEX idx_ShowID ON Wins(ShowID);*/